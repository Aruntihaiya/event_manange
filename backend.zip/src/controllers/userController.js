
// const bcrypt = require("bcryptjs");
// const JWT = require("jsonwebtoken");
// const db = require("../models/index");
// const User = db.user;

// const userController = {
//   async register(req, res) {
//     try {
//       // checking user's existence
//       console.log(req.body)
//       const exists = await User.findOne({
//         where: {
//           email: req.body.email
//         },
//       });
//       if (exists) {
//         res.status(200).json({
//           msg: "This Email is already exists", success: false,
//         });
//       }
//       else {
//         const hashedPass = await bcrypt.hash(req.body.password, 10);
//         const document = User.build({
//           name: req.body.name,
//           email: req.body.email,
//           phone: req.body.phone,
//           password: hashedPass,

//         });

//         var userResult = await document.save();


//         if (userResult) {
//           // res.json({ userResult, userAddress });
//           res.status(201).json({
//             msg: " Registraion Successfully",
//             success: true,
//             data: userResult,
//           });
//         } else {
//           res.status(400).json({ msg: "Something went wrong" });
//         }
//       }

//     } catch (error) {
//       res.status(500).json(error);
//       console.log(error);
//     }
//   },
//   // login
//   async login(req, res) {
//     try {
//       let email = req.body.email;
//       let password = req.body.password;

//       const findUser = await User.findOne({ 
//         where: {
//           email: req.body.email
//         },
//       });
//       if (findUser) {
//         const isMatch = await bcrypt.compare(password, findUser.password);
//         if (isMatch) {
//         const token = JWT.sign({ uId: findUser.id }, process.env.TOKEN_KEY, {
//             expiresIn: "15 minutes",
//         });
//           //  console.log(token);
//         res.json({ msg: " Login Successfully", success: true, token: token,data:findUser });
//         } else {
//         res.json({ msg: "Invalid Login Details", success: false });
//       }
//       } else {
//         res.json({ msg: "Invalid Login Details", success: false });
//       }
//     } catch (error) {
//       res.json({ msg: `Something Went Wrong ${error}`, success: false });
//       console.log(error);
//     }
//   },

// };

// module.exports = userController;
