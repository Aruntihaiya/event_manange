import express from 'express';
import validate from 'express-validation';



const router = express.Router();

//= ===============================
// API routes
//= ===============================
//router.post('/me', userController.profile);

module.exports = router;
