import express from 'express';
import validate from 'express-validation';
import blogController from '../controllers/blogController';


const router = express.Router();

//= ===============================
// Public routes
//= ===============================

 router.get('/userdetails', blogController.getuser);




module.exports = router;
